/**
 * Teacher: Ms. Krasteva ICS4U0
 * Description: This subclass contains the GreedyBird constructor and the
 * methods that affect the GreedyBird objects
 * It also extends from the Bird class, since it is a kind of bird
 * 
 * @author Jessica Chen (With Avery lee, Avery Mai)
 * @version 02/20/23
 */

public class GreedyBird extends Bird {

    /*
     * The beginning of the code
     * Different variables are declared
     */
    private boolean greed;
    private String volume;
    private boolean banish;

    /*
     * The "GreedyBird" class constructor
     * Variables are assigned to values of an "original bird"
     */
    public GreedyBird() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = false;
        type = "bird";
    }

    /**
     * method "hungerGold"
     * sets the hunger variable to true
     */
    public void setHunger() {
        if (gooseAsleep == true) {
            hunger = true;
            System.out.println("The bird sees the stash of gold the goose is hiding and is now hungry!");
        }
    }

    /**
     * method "speechVolume"
     * sets the volume String to loud
     */
    public void speechVolume() {
        if (greed = true) {
            volume = "loud";
            System.out.println("The chatty bird tells everyone about the stash of gold.");
        }
    }

    /**
     * method "banishLand"
     * banishes the bird from the land when he gets caught stealing
     */
    public void banishLand() {
        if (volume == "loud") {
            gooseAsleep = false;
            banish = true;
            System.out.print("Oh no! He talked too loudly he woke up the goose.");
            System.out.println("The goose becomes very angry and named the bird \"seagull\" before banishing the bird from the land.");
        }                        
    }
    
    /**
     * method "toSeagull"
     * sets the following attributes to accommodate for the changes made
     */
    public void toSeagull() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = true;
        type = "seagull";
    }

    /**
     * method "printSeagull"
     * prints out messages regarding the process of the seagull being made
     */
    public void printSeagull() {
        System.out.print("The ");
        if (greed) {
            System.out.print("greedy ");
        }
        System.out.print(volume + " " + type + " is " + color + ", weighs " + weight + "lbs, and is ");
        if (hunger) {
            System.out.println("hungry.");
        } else {
            System.out.println(" not hungry.");
        }
        if (banish) {
            System.out.println("The " + type + " is also banished for his crime.");
        }
    }
}
