/**
 * Teacher: Ms. Krasteva ICS4U0
 * Description: This subclass contains the StealingBird constructor and the
 * methods that affect the StealingBird objects
 * It also extends from the Bird class, since it is a kind of bird
 * 
 * @author Avery Mai (with Avery Lee, Jessica Chen)
 * @version 02/20/23
 */

public class StealingBird extends Bird {

    /*
     * The beginning of the code
     * Different variables are declared
     */
    private double wealth = 0;
    private boolean caught;
    private boolean steal;
    private int talons = 4;

    /*
     * The "StealingBird" class constructor
     * Different variables are assigned
     */
    public StealingBird() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = false;
        type = "bird";
    }

    /*
     * method "setSteal"
     * sets the steal variable to true if the goose is asleep
     * prints the corresponding section of the story
     */
    public void setSteal() {
        if (gooseAsleep) {
            steal = true;
            System.out.print("Delighted by the first bird's discovery of gold, ");
            System.out.println("a second bird decided to try and snag some riches for itself.");
        }
    }

    /*
     * method "setWealth"
     * increases the wealth variable by a constant set in the call if the hawk is in steal mode
     * prints the corresponding section of the story
     */
    public void setWealth(int w) {
        if (steal) {
            wealth += w;
            System.out.print("The bird successfully made it into the goose's net unnoticed, ");
            System.out.println("stealing as many gold coins as its talons could hold.");
        }
    }

    /*
     * method "wakeGoose"
     * sets the gooseAsleep variable to false if the hawk is too greedy and steals over 8 gold coins
     * prints the corresponding section of the story
     */
    public void wakeGoose() {
        if (wealth >= 8) {
            gooseAsleep = false;
            System.out.print("The bird got too greedy, and accidentally dropped a couple coins as it tried to escape the nest. ");
            System.out.println("The goose was awoken!");
        }
    }

    /*
     * method "setGaught"
     * sets the caught variable to true if the goose is awake and catches the hawk
     * prints the corresponding section of the story
     */
    public void setCaught() {
        if (gooseAsleep) {
            caught = true;
            System.out.println("The goose was able to quickly catch the guilty bird.");
        }
    }

    /*
     * method "setTalon"
     * reduces the talons variable by 2 if it is caught stealing
     * prints the corresponding section of the story
     */
    public void setTalon() { 
        if (caught) {
            talons -= 2;
            System.out.print("This bird managed to talk its way out of banishment, but had to suffer a consequence nonetheless. ");
            System.out.print("Two of its talons were confiscated, leaving it with only two talons on each leg. ");
            System.out.println("This modification earned the bird the title of hawk, and its color changed to red as a result.");
        }
    }

    /**
     * method "toHawk"
     * sets the following attributes to accommodate for the changes made
     */
    public void toHawk() {
        type = "hawk";
        color = "red";
    }

    /**
     * method "printHawk"
     * prints out messages regarding the process of the hawk being made
     */
    public void printHawk() {
        System.out.print("The ");
        if (wealth >= 10) {
            System.out.print("rich ");
        }
        System.out.print(type + " has " + talons + " talons, is " + color + ", weighs " + weight + "lbs, and is ");
        if (hunger) {
            System.out.println("hungry.");
        } else {
            System.out.println("not hungry.");
        }
        if (fly) {
            System.out.println("The " + type + " is still able to fly.");
        } else {
            System.out.println("The " + type + " is unable to fly.");
        }
    }
}