/**
 * Teacher: V. Krasteva ICS4U0
 * Description: This program contains the Bird class constructor and the methods
 * than affect the Bird objects
 * 
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 02/20/23
 */

public class Bird {

    /**
     * The beginning of the program, with class name "Bird"
     * Different variables are made
     */
    public boolean fly;
    public String color;
    public int weight;
    public boolean hunger;
    public String type;
    public boolean gooseAsleep;

    /*
     * method "printIntro"
     * prints the introduction to the story
     */
    public void printIntro() {
        System.out.print("This is the story of how chickens, seagulls, hawks, and kiwis came to be on Earth. ");
        System.out.print("By being greedy, stealing, and hungry, the birds one by one fell from the heavans ");
        System.out.println("and gained the characteristics that they still have to this day.");
        System.out.println("After reading this story, you will learn to never be greedy again!");
    }

    /**
     * The "Bird" class constructor
     * Variables are assigned to values of an "original bird"
     */

    public Bird() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = false;
        type = "bird";
    }

    /**
     * method "gooseState"
     * sets the goose's state to asleep
     */
    public void gooseState() {
        gooseAsleep = true;
    }

    /**
     * method "canFly"
     * returns the fly variable (which indicates whether the bird can fly)
     */
    public boolean canFly() {
        return fly;
    }

    /**
     * method "getColor"
     * returns the color variable (which indicates the color of the bird)
     */
    public String getColor() {
        return color;
    }

    /**
     * method "getWeight"
     * returns the weight variable (which indicates the weight of the bird)
     */
    public int getWeight() {
        return weight;
    }

    /**
     * method "isGreed"
     * returns the greed variable (which indicates whether the bird is greedy)
     */
    public boolean isHungry() {
        return hunger;
    }

    /**
     * method "message"
     * prints the messages that indicate attributes of the original bird
     */
    public void printBird() {
        System.out.print("At the beginning, all the birds were made equal. ");
        if (fly)
            System.out.print("They were able to fly, ");
        else
            System.out.print("They weren't able to fly, ");
        System.out.print("they were all the same color, " + color + ", ");
        System.out.print("all weighed exactly " + weight + "lbs, ");
        if (hunger)
            System.out.print("were all hungry, ");
        else
            System.out.print("were never hungry, ");
        System.out.println("and were all the same type: " + type + ".");
    }
}