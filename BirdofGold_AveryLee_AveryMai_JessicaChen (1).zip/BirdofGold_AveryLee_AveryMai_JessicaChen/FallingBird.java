/**
 * Teacher: Ms. Krasteva ICS4U0
 * Description: This subclass contains the FallingBird constructor and the
 * methods that affect the FallingBird objects
 * It also extends from the Bird class, since it is a kind of bird
 * 
 * @author Avery Lee (with Avery Mai, Jessica Chen)
 * @version 02/20/23
 */

public class FallingBird extends Bird {

    /*
     * The beginning of the program
     * Different variables are declared
     */
    private boolean alive;
    private int yCoord;
    private boolean falling;

    /*
     * The "FallingBird" class constructor
     * Different variables are assigned
     */
    public FallingBird() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = false;
        type = "bird";
        alive = true;
        yCoord = 1000;
        falling = false;
    }

    /*
     * method "setHunger"
     * sets the hunger to true once goose falls asleep.
     */
    public void setHunger() {
        if (gooseAsleep) {
            hunger = true;
            System.out.println("The bird is now hungry!");
        }
    }

    /*
     * method "weightGold"
     * increase the weight of the bird after eating, set hunger to false (full), start falling down
     */
    public void weightGold() {
        if (hunger) {
            weight += 10;
            hunger = false;
            falling = true;
            System.out.println("The bird has now gained ten pounds and is full. Oh no! It's falling down!");
        }
    }

    public void falling() {
        if (falling) {
            toKiwi();
            System.out.println("The elevation of the bird is: ");
        }
        while (falling) {
            color = "brown";
            yCoord -= 100;
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            System.out.println(yCoord + "m");
            if (yCoord <= 1) {
                yCoord = 0;
                alive = false;
                weight = 8;
                falling = false;
                color = "red";
                System.out.println("The kiwi bird has fallen and died :(");
                flyGold();
            }
        }
    }

    /*
     * method "printKiwi"
     * prints out the all the attributes of the bird type
     */
    public void printKiwi() {
        System.out.print("The " + type + " is " + color + ", weighs " + weight + "lbs, and is ");
        if (alive)
            System.out.println("alive.");
        else
            System.out.println("dead.");
    }

    /*
     * method "flyGold"
     * sets the fly boolean to false (because it can't fly)
     */
    public void flyGold() {
        fly = false;
        System.out.println("And now, the bird is unable to fly.");
    }

    /*
     * method "toKiwi"
     * sets the bird to the kiwi type
     */
    public void toKiwi() {
        type = "kiwi";
        System.out.println("That is how the falling bird became the kiwi!");
    }
}