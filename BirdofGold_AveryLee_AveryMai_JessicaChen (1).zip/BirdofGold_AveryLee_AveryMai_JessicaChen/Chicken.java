/**
 * Teacher: Ms. Krasteva ICS4U0
 * Description: This subclass contains the Chicken constructor and the methods
 * that affect the Chicken objects
 * It also extends from the Bird class, since it is a kind of bird
 * 
 * @author Avery Lee, Avery Mai, Jessica Chen
 * @version 02/20/23
 */

public class Chicken extends Bird {

    /*
     * The beginning of the program
     * Different variables are declared
     */
    private String personality;
    private boolean copyCat;
    private boolean falling;
    private int yCoord = 1000;

    /*
     * The "Chicken" class constructor
     * Different variables are assigned
     */
    public Chicken() {
        fly = true;
        color = "white";
        weight = 2;
        hunger = false;
        type = "bird";
    }

    /*
     * The "birdCopyCat" method
     * the last bird copies what all the birds have done previously
     */
    public void birdCopyCat() {
        System.out.println(
                "Seeing the previous three birds fail, the last bird decides to copy their actions, hoping to succeed.");
        copyCat = true;
    }

    /*
     * The "birdPersonality" method
     * the last bird becomes arrogant of his plan to steal the gold
     */
    public void birdPersonality() {
        System.out.println(
                "The bird devises a meticulous plan, and becomes very prideful that his scheme is one-of-a-kind.");
        personality = "prideful";
    }

    /*
     * method "hungerGold"
     * sets the hunger variable to true, making the bird greedy (because it saw the
     * gold)
     */
    public void hungerGold() {
        System.out.println("Like the previous birds, the last one sees the stash of gold becomes hungry. ");
        hunger = true;
    }

    /*
     * method "weightGold"
     * adds 10 to the weight value if the bird is greedy (because it ate gold)
     */
    public void weightGold() {
        if (hunger == true)
            weight += 10;
        System.out.print("As the bird eats and eats, it gets heavier and heavier.");
        if (weight > 2) {
            falling = true;
            System.out.println(
                    "After the bird finishes eating, he fells himself sinking through the clouds. He is falling!");
        }
    }

    /*
     * method "falling"
     * calls "toChicken" method that assigns the bird type to chicken
     * the bird plummets to the land of mortals and becomes ashamed
     */
    public void falling() {
        if (falling) {
            toChicken();
            System.out.println("As the bird falls, he turns yellow and realizes he can't fly. He is turning into a chicken!");
            System.out.println("The elevation of the bird is: ");
        }
        while (falling) {
            yCoord -= 100;
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            System.out.println(yCoord + "m");
            if (yCoord <= 1) {
                falling = false;
                System.out.println("The chicken lands in the world of mortals. He is no longer prideful and is ashamed of himself.");
                personality = "ashamed";
            }
        }
    }

    /*
     * method "isChicken"
     * sets the type variable to chicken if the requirements are fulfilled
     */
    public void toChicken() {
        fly = false;
        color = "yellow";
        weight = 12;
        hunger = true;
        type = "chicken";
    }

    /*
     * method "printChicken"
     * prints out the all the attributes of the bird type
     */
    public void printChicken() {
        System.out.print("The " + personality + ", " + color + " chicken now weighs " + weight + "lbs, and is ");
        if (hunger) {
            System.out.println("hungry.");
        } else {
            System.out.println(" not hungry.");
        }
    }
}