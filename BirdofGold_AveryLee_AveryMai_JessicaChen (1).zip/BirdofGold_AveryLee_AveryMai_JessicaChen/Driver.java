/**
 * Teacher: Ms. Krasteva ICS4U0
 * Description: This subclass is the driver class, which runs the methods from the other classes
 * 
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 02/20/23
 */

public class Driver {
    /**
     * main method to execute methods
     * @param args arguments passed from the command line
     */

    public static void main(String[] args) {
        /** creates a new Bird object */
        Bird bird = new Bird();
        bird.printBird();
        System.out.println();

        /** creates a new GreedyBird object */
        GreedyBird seagull = new GreedyBird();
        seagull.gooseAsleep = true;
        seagull.setHunger();
        seagull.speechVolume();
        seagull.banishLand();
        seagull.toSeagull();
        seagull.printSeagull();
        System.out.println();
        

        /** creates a new StealingBird object */
        StealingBird hawk = new StealingBird();
        hawk.gooseAsleep = true;
        hawk.setSteal();
        hawk.setWealth(10);
        hawk.wakeGoose();
        hawk.setCaught();
        hawk.setTalon();
        hawk.toHawk();
        hawk.printHawk();
        System.out.println();

        /** creates a new FallingBird object */
        FallingBird kiwi = new FallingBird();
        kiwi.gooseAsleep = true;
        kiwi.setHunger();
        kiwi.weightGold();
        kiwi.falling();
        kiwi.printKiwi();
        System.out.println();

        /** creates a new Chicken object */
        Chicken chicken = new Chicken();
        chicken.birdCopyCat();
        chicken.birdPersonality();
        chicken.hungerGold();
        chicken.weightGold();
        chicken.falling();
        chicken.toChicken();
        chicken.printChicken();
        System.out.println();

        System.out.println("The End");
        System.out.println();
    }
}
